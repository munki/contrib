#!/bin/sh

THISDIR=`dirname $0`
cd "$THISDIR"
if [ ! -d ./mwa2 ] ; then
    echo "*** Cloning MWA2 from GitHub ***"
    git clone https://github.com/munki/mwa2.git
fi
if [ ! -f ./mwa2/munkiwebadmin/settings.py ]; then
    echo "*** Copying settings template ***"
    cp ./mwa2/munkiwebadmin/settings_template.py ./mwa2/munkiwebadmin/settings.py
    echo "Edit $THISDIR/mwa2/munkiwebadmin/settings.py:"
    echo "    Change MUNKI_REPO_DIR (near the end of the file) to point to your Munki repo."
    echo "Then run this script again to continue setup tasks."
    exit 0
fi
if [ ! -f ./mwa2/db.sqlite3 ]; then
    echo "*** Creating Django database for MWA2 ***"
    bin/python mwa2/manage.py migrate
    if [ "$?" -ne 0 ]; then
        exit "$?"
    fi
    echo '***Creating superuser account for MWA2***'
    bin/python mwa2/manage.py createsuperuser
    if [ "$?" -ne 0 ]; then
        exit "$?"
    fi
fi
echo "*** Starting MWA2 ***"
bin/python mwa2/manage.py runwsgiserver host=0.0.0.0 port=8080